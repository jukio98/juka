astra=[
"Placa: DWL-6A68",
"Cor: BLUET",
"Oleo: 06/01/2024",
"Próxima Troca_oleo: 06/05/2024",
"TROCAR A CADA 4 MESES",
]